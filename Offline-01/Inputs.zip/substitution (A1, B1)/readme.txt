Please work on your specefied text file. Otherwise you will get zero. 

Each file contains three lines
1st line denotes the ciphertext that you need to decode

2nd line metions the most frequent three characters in the plaintext. For example: e, t, a means that e has highest frequency, t has 2nd highest  and a has 3rd highest

3rd line denotes some words that are present in the plaintext. Use the words to find the mapping. 